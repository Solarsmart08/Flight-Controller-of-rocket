#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_BMP280.h>

// ---------- Function Prototypes ----------
void wireChangeHandler();
void logSensorData(unsigned long timestamp);
void logDeployment(uint8_t eventID, unsigned long timestamp);
void buzzPattern(int count);

// ---------- Event IDs ----------
#define EVT_INTERRUPT           1
#define EVT_EJECT1              2
#define EVT_EJECT2              3
#define EVT_EJECT1_ALT_DROP     4

// ---------- Sensor Objects ----------
Adafruit_MPU6050 mpu;
Adafruit_BMP280 bmp;

// ---------- SD ----------
File myFile;

// ---------- Altitude Variables ----------
float pnot;
float maxAltitude;
bool maxAltInitialized = false;
float altitudeAtInterrupt = 0;
float altitudeAtEjection1 = 0;
float altitudeAtEjection2 = 0;
float altitudeRefForDrop = 0;


// ---------- Altitude Drop Logic ----------
const float ALTITUDE_DROP_THRESHOLD = 50.00;

// ---------- Pins ----------
const int ledPin1 = 7;
const int ledPin2 = 6;
const int statusLedPin = 5;
const int interruptPin = 2;
const int buzzerPin = 3;

// ---------- Flags ----------
volatile bool wireCut = false;
bool trigger = true;
unsigned long startTime = 0;
bool timerArmed = false;   // ONLY for timer
  // becomes true ONLY after wire cut
bool apogeeLocked = false;   // locks max altitude after peak



const unsigned long timerDuration = 11000;
unsigned long firstLedOnTime = 0;

// ---------- Module Status ----------
bool sdOK = false;
bool mpuOK = false;
bool bmpOK = false;

// ---------- Deployment Cause ----------
uint8_t firstEjectionCause = 0;

// ---------- LED Blink Control ----------
unsigned long lastBlinkTime = 0;
bool ledState = false;

// ===================== SETUP =====================
void setup() {
  Serial.begin(9600);

  pinMode(ledPin1, OUTPUT);
  pinMode(ledPin2, OUTPUT);
  pinMode(statusLedPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(interruptPin, INPUT_PULLUP);

  digitalWrite(ledPin1, LOW);
  digitalWrite(ledPin2, LOW);
  digitalWrite(statusLedPin, LOW);

  buzzPattern(3);

  if (!SD.begin(4)) {
    Serial.println(F("ERROR: SD card initialization failed!"));
  } else {
    sdOK = true;
  }

  if (!mpu.begin(0x68)) {
    Serial.println(F("ERROR: MPU6050 initialization failed!"));
  } else {
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    mpuOK = true;
  }

  if (!bmp.begin(0x76)) {
    Serial.println(F("ERROR: BMP280 initialization failed!"));
  } else {
    bmp.setSampling(
      Adafruit_BMP280::MODE_NORMAL,
      Adafruit_BMP280::SAMPLING_X2,
      Adafruit_BMP280::SAMPLING_X16,
      Adafruit_BMP280::FILTER_X16,
      Adafruit_BMP280::STANDBY_MS_500
    );
    pnot = bmp.readPressure() / 100.0F;
    bmpOK = true;
  }

  if (sdOK && mpuOK && bmpOK) {
    buzzPattern(3);
  }

  attachInterrupt(digitalPinToInterrupt(interruptPin), wireChangeHandler, RISING);
}

// ===================== LOOP =====================
void loop() {

  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  float altitude = bmp.readAltitude(pnot);

 // ---------- Max Altitude Tracking ----------
// ---------- Max Altitude Tracking ----------
// ---------- Altitude Reference Update ----------
if (!maxAltInitialized) {
  maxAltitude = altitude;
  altitudeRefForDrop = altitude;
  maxAltInitialized = true;
}

// Update ONLY if wire not cut
else if (!timerArmed && altitude > maxAltitude) {
  maxAltitude = altitude;
  altitudeRefForDrop = maxAltitude;
}




  float angle_y = atan2(a.acceleration.y,
                        sqrt(a.acceleration.z * a.acceleration.z +
                             a.acceleration.x * a.acceleration.x)) * 180 / PI;

  float angle_z = atan2(a.acceleration.z,
                        sqrt(a.acceleration.x * a.acceleration.x +
                             a.acceleration.y * a.acceleration.y)) * 180 / PI;

  // ================= SENSOR HEALTH LED (D5) =================
  bool sensorFault =
    isnan(altitude) || altitude == 0 ||
    isnan(a.acceleration.x) || isnan(a.acceleration.y) || isnan(a.acceleration.z) ||
    isnan(g.gyro.x) || isnan(g.gyro.y) || isnan(g.gyro.z);

  if (sensorFault) {
    if (millis() - lastBlinkTime >= 1000) {
      lastBlinkTime = millis();
      ledState = !ledState;
      digitalWrite(statusLedPin, ledState);
    }
  } else {
    digitalWrite(statusLedPin, HIGH);
  }
  // ==========================================================

  // ---------- Interrupt ----------
  // ---------- Interrupt ----------
// ---------- Interrupt ----------
// ---------- Interrupt ----------
// ---------- Interrupt ----------
if (wireCut && !timerArmed && trigger) {
  wireCut = false;

  timerArmed = true;
  startTime = millis();

  altitudeAtInterrupt = altitude;
  altitudeRefForDrop = altitude;   // 🔥 FREEZE reference here

  logDeployment(EVT_INTERRUPT, millis());
}


// ---------- First Ejection (Altitude Drop - ALWAYS ACTIVE) ----------
// ---------- First Ejection (Altitude Drop - INDEPENDENT) ----------
// ---------- First Ejection (Altitude Drop - TRUE INDEPENDENT) ----------
if ((altitudeRefForDrop - altitude) >= ALTITUDE_DROP_THRESHOLD && trigger) {

  digitalWrite(ledPin1, HIGH);
  digitalWrite(buzzerPin, HIGH);

  firstLedOnTime = millis();
  altitudeAtEjection1 = altitude;

  trigger = false;
  timerArmed = false;
  startTime = 0;

  firstEjectionCause = 3;
  logDeployment(EVT_EJECT1_ALT_DROP, millis());
}

// ---------- First Ejection (Gyration - ALWAYS ACTIVE) ----------
// ---------- First Ejection (Gyration - INDEPENDENT) ----------
if (altitude >= 400 &&
    (abs(angle_y) >= 45 || abs(angle_z) >= 45) &&
    trigger) {

  digitalWrite(ledPin1, HIGH);

  firstLedOnTime = millis();
  altitudeAtEjection1 = altitude;

  trigger = false;
  timerArmed = false;
  startTime = 0;

  firstEjectionCause = 2;
  logDeployment(EVT_EJECT1, millis());
}

// ---------- First Ejection (Timer - ONLY wire cut dependent) ----------
// ---------- First Ejection (Timer - ONLY wire cut) ----------
if (timerArmed &&
    startTime != 0 &&
    millis() - startTime >= timerDuration &&
    trigger) {

  digitalWrite(ledPin1, HIGH);

  firstLedOnTime = millis();
  altitudeAtEjection1 = altitude;

  trigger = false;
  timerArmed = false;
  startTime = 0;

  firstEjectionCause = 1;
  logDeployment(EVT_EJECT1, firstLedOnTime);
}

  // ---------- First Ejection (Timer) ----------
  // ---------- First Ejection (Timer - ONLY wire cut dependent) ----------
// ---------- First Ejection (Timer - wire cut only) ----------

  // if (altitude < maxAltitude && altitude >= 1) {
  //   digitalWrite(buzzerPin, HIGH);
  //   delay(300);
  //   digitalWrite(buzzerPin, LOW);
  // }

  // ---------- Second Ejection ----------
  if (firstLedOnTime != 0 && millis() - firstLedOnTime >= 2000) {
    digitalWrite(ledPin1, LOW);
    digitalWrite(ledPin2, HIGH);
    digitalWrite(buzzerPin, LOW);   // 🔕 stop buzzer after second charge
    altitudeAtEjection2 = altitude;
    firstLedOnTime = 0;
    logDeployment(EVT_EJECT2, millis());
  }

  logSensorData(millis());
}

// ===================== INTERRUPT =====================
void wireChangeHandler() {
  wireCut = true;
}

// ===================== SENSOR LOG =====================
void logSensorData(unsigned long timestamp) {
  sensors_event_t a, g, temp_mpu;
  mpu.getEvent(&a, &g, &temp_mpu);

  float temperature_bmp = bmp.readTemperature();
  float pressure = bmp.readPressure() / 100.0F;
  float altitude = bmp.readAltitude(pnot);

  myFile = SD.open("Data.txt", FILE_WRITE);
  if (myFile) {

    myFile.print(timestamp / 1000.0, 2);
    myFile.print(F(" "));

    myFile.print(F("BMP Altitude -> "));
    myFile.print(altitude);
    myFile.println(F(" m"));

    myFile.print(F("BMP Temperature -> "));
    myFile.print(temperature_bmp);
    myFile.println(F(" °C"));

    myFile.print(F("BMP Pressure -> "));
    myFile.print(pressure);
    myFile.println(F(" hPa"));

    myFile.print(F("MPU Acceleration -> X="));
    myFile.print(a.acceleration.x);
    myFile.print(F(", Y="));
    myFile.print(a.acceleration.y);
    myFile.print(F(", Z="));
    myFile.println(a.acceleration.z);

    myFile.print(F("MPU Gyroscope -> X="));
    myFile.print(g.gyro.x);
    myFile.print(F(", Y="));
    myFile.print(g.gyro.y);
    myFile.print(F(", Z="));
    myFile.println(g.gyro.z);

    myFile.print(F("MPU Temperature -> "));
    myFile.print(temp_mpu.temperature);
    myFile.println(F(" °C"));

    myFile.close();
  }
  delay(100);
}

// ===================== DEPLOYMENT LOG =====================
void logDeployment(uint8_t eventID, unsigned long timestamp) {

  myFile = SD.open("time.txt", FILE_WRITE);
  if (!myFile) return;

  if (eventID == EVT_INTERRUPT) {
    myFile.println(F("Interrupt Cut Event"));
    myFile.print(F("Altitude at Interrupt Cut -> "));
    myFile.print(altitudeAtInterrupt);
    myFile.println(F(" m"));
  }

  if (eventID == EVT_EJECT1) {
    if (firstEjectionCause == 1)
      myFile.println(F("First Ejection (Timer Based)"));
    else if (firstEjectionCause == 2)
      myFile.println(F("First Ejection (Gyration Based)"));

    myFile.print(F("Altitude at First Ejection -> "));
    myFile.print(altitudeAtEjection1);
    myFile.println(F(" m"));
  }

  if (eventID == EVT_EJECT1_ALT_DROP) {
    myFile.println(F("First Ejection (Altitude Drop Based)"));
    myFile.print(F("Altitude at First Ejection -> "));
    myFile.print(altitudeAtEjection1);
    myFile.println(F(" m"));
  }

  if (eventID == EVT_EJECT2) {
    myFile.println(F("Second Ejection Event"));
    myFile.print(F("Altitude at Second Ejection -> "));
    myFile.print(altitudeAtEjection2);
    myFile.println(F(" m"));

    myFile.print(F("Final Highest Altitude -> "));
    myFile.print(maxAltitude);
    myFile.println(F(" m"));
    myFile.println(F("===== END OF FLIGHT ====="));
  }

  myFile.println(F("-----------------------------"));
  myFile.close();
}

// ===================== BUZZER =====================
void buzzPattern(int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(buzzerPin, HIGH);
    delay(200);
    digitalWrite(buzzerPin, LOW);
    delay(200);
  }
  delay(500);
}